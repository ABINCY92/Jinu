

import connection.DatabaseConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 @WebServlet(urlPatterns = {"/reportview"})
    public class reportview extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession(true);
         try{
        Connection con=null; 
        Statement st=null;
        DatabaseConnection db1=new DatabaseConnection();
        String username=request.getParameter("uname");
        String stratdate=request.getParameter("stratdate");
        String enddate=request.getParameter("enddate");
        String query = "SELECT * FROM fileupload1 WHERE  date BETWEEN '"+stratdate+"' and '"+enddate+"' and username='"+username+"' order by date asc";
        ResultSet i=db1.Select(query);
                if(i.next())
                {
                   session.setAttribute("date",stratdate);
                   session.setAttribute("date", enddate);
                   session.setAttribute("Username", username);
                   
                   request.setAttribute("Username", username);
                   request.setAttribute("date1", stratdate);
                   request.setAttribute("date", enddate);
                   session.setAttribute("msg","Successfully Entered");
                   RequestDispatcher rd=request.getRequestDispatcher("Reportview.jsp"); 
                   rd.forward(request, response);
                }
                else
                {
                  session.setAttribute("msg","This date data not avilable...");
                  response.sendRedirect("report.jsp");
                }
                }
         
         catch(Exception e)
         {
         }
         out.close();
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        processRequest(request, response);       
    }     
    }
